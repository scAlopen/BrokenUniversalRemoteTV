import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useBluetooth } from "@/components/bluetooth-provider"
import { apiRequest, queryClient } from "@/lib/queryClient"
import { formatLastConnected } from "@/lib/utils"
import { 
  Tv, 
  Bluetooth, 
  Plus, 
  Trash2, 
  Settings, 
  Wifi,
  WifiOff,
  Scan
} from "lucide-react"
import type { Device } from "../../shared/schema"

export function DevicesPage() {
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null)
  const { toast } = useToast()
  const { scanForDevices, connectToDevice, disconnectDevice, availableDevices, connectionStatus } = useBluetooth()

  const { data: devices = [], isLoading, refetch } = useQuery<Device[]>({
    queryKey: ['/api/devices'],
  })

  const deleteDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      return apiRequest(`/api/devices/${deviceId}`, {
        method: 'DELETE',
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/devices'] })
      toast({
        title: "Device Removed",
        description: "Device has been successfully removed",
      })
    },
    onError: (error) => {
      toast({
        title: "Failed to Remove Device",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      })
    },
  })

  const connectMutation = useMutation({
    mutationFn: async ({ deviceId, pairingCode }: { deviceId: string; pairingCode?: string }) => {
      await connectToDevice(deviceId, pairingCode)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/devices'] })
    },
  })

  const disconnectMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      await disconnectDevice(deviceId)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/devices'] })
    },
  })

  const handleConnect = async (deviceId: string) => {
    const device = devices.find(d => d.id === deviceId)
    if (device?.pairingCode) {
      const code = prompt(`Enter pairing code for ${device.name}:`)
      if (code) {
        connectMutation.mutate({ deviceId, pairingCode: code })
      }
    } else {
      connectMutation.mutate({ deviceId })
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 w-48 bg-muted rounded mb-6"></div>
          <div className="grid gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Device Management</h1>
          <p className="text-muted-foreground">
            Manage your connected TVs and streaming devices
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            onClick={scanForDevices}
            disabled={connectionStatus === "scanning"}
            variant="outline"
          >
            <Scan className="h-4 w-4 mr-2" />
            {connectionStatus === "scanning" ? "Scanning..." : "Scan for Devices"}
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Device
          </Button>
        </div>
      </div>

      {/* Available Devices from Scan */}
      {availableDevices.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Available Devices</CardTitle>
            <CardDescription>
              Devices found during the last Bluetooth scan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {availableDevices.map((device) => (
                <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Bluetooth className="h-5 w-5 text-blue-500" />
                    <div>
                      <p className="font-medium">{device.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {device.brand} {device.model}
                      </p>
                    </div>
                  </div>
                  <Button 
                    onClick={() => handleConnect(device.id)}
                    disabled={connectMutation.isPending}
                    size="sm"
                  >
                    {device.isPaired ? "Connect" : "Pair & Connect"}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Paired Devices */}
      <div className="grid gap-4">
        {devices.map((device) => (
          <Card key={device.id} className={`transition-all ${selectedDevice === device.id ? 'ring-2 ring-primary' : ''}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Tv className="h-6 w-6" />
                  <div>
                    <CardTitle className="text-xl">{device.name}</CardTitle>
                    <CardDescription>
                      {device.brand} {device.model}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${device.isConnected ? 'bg-green-500' : 'bg-gray-400'}`} />
                  <span className="text-sm font-medium">
                    {device.isConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h4 className="font-medium mb-2">Device Information</h4>
                  <div className="space-y-1 text-sm">
                    <p><span className="text-muted-foreground">Type:</span> {device.type}</p>
                    <p><span className="text-muted-foreground">Bluetooth ID:</span> {device.bluetoothId || 'N/A'}</p>
                    <p><span className="text-muted-foreground">IP Address:</span> {device.ipAddress || 'N/A'}</p>
                    <p><span className="text-muted-foreground">Last Connected:</span> {formatLastConnected(device.lastConnected)}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Supported Features</h4>
                  <div className="flex flex-wrap gap-1">
                    {device.supportedFeatures?.map((feature) => (
                      <span 
                        key={feature} 
                        className="px-2 py-1 bg-secondary text-secondary-foreground rounded-md text-xs"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                <div className="flex space-x-2">
                  {device.isConnected ? (
                    <Button 
                      onClick={() => disconnectMutation.mutate(device.id)}
                      disabled={disconnectMutation.isPending}
                      variant="outline"
                      size="sm"
                    >
                      <WifiOff className="h-4 w-4 mr-2" />
                      Disconnect
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => handleConnect(device.id)}
                      disabled={connectMutation.isPending}
                      size="sm"
                    >
                      <Wifi className="h-4 w-4 mr-2" />
                      Connect
                    </Button>
                  )}
                  
                  <Button 
                    onClick={() => window.location.href = `/remote/${device.id}`}
                    variant="outline" 
                    size="sm"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Control
                  </Button>
                </div>
                
                <Button 
                  onClick={() => deleteDeviceMutation.mutate(device.id)}
                  disabled={deleteDeviceMutation.isPending}
                  variant="destructive" 
                  size="sm"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Remove
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {devices.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Tv className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Devices Found</h3>
            <p className="text-muted-foreground mb-4">
              Start by scanning for nearby Bluetooth devices or manually adding a device.
            </p>
            <div className="flex justify-center space-x-2">
              <Button onClick={scanForDevices}>
                <Scan className="h-4 w-4 mr-2" />
                Scan for Devices
              </Button>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Manually
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}