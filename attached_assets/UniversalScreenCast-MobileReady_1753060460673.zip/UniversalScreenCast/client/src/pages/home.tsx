import { useQuery } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useBluetooth } from "@/components/bluetooth-provider"
import { Link } from "wouter"
import { 
  Tv, 
  Bluetooth, 
  Play, 
  Home as SmartHomeIcon,
  Scan,
  Wifi,
  Power,
  Volume2
} from "lucide-react"
import { formatLastConnected } from "@/lib/utils"
import type { Device } from "../../shared/schema"

export function HomePage() {
  const { connectionStatus, connectedDevice, scanForDevices } = useBluetooth()
  
  const { data: devices = [], isLoading } = useQuery<Device[]>({
    queryKey: ['/api/devices'],
  })

  const { data: connectedDevices = [] } = useQuery<Device[]>({
    queryKey: ['/api/devices/connected'],
  })

  const quickActions = [
    { 
      icon: Bluetooth, 
      label: "Scan Devices", 
      action: scanForDevices,
      color: "bg-blue-600 hover:bg-blue-700" 
    },
    { 
      icon: Play, 
      label: "Launch Netflix", 
      action: () => {}, 
      color: "bg-red-600 hover:bg-red-700",
      href: "/streaming" 
    },
    { 
      icon: Volume2, 
      label: "Volume Control", 
      action: () => {}, 
      color: "bg-green-600 hover:bg-green-700",
      href: "/remote" 
    },
    { 
      icon: SmartHomeIcon, 
      label: "Smart Home", 
      action: () => {}, 
      color: "bg-purple-600 hover:bg-purple-700",
      href: "/smart-home" 
    },
  ]

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 w-64 bg-muted rounded mb-4"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Universal TV Remote</h1>
        <p className="text-muted-foreground">
          Control your TV, streaming devices, and smart home from anywhere
        </p>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bluetooth className="h-5 w-5" />
            <span>Connection Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              {connectedDevice ? (
                <div>
                  <p className="font-medium text-green-600">
                    Connected to {connectedDevice.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {connectedDevice.brand} {connectedDevice.model}
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-medium">No device connected</p>
                  <p className="text-sm text-muted-foreground">
                    Status: {connectionStatus}
                  </p>
                </div>
              )}
            </div>
            <div className="flex space-x-2">
              <Button 
                onClick={scanForDevices}
                disabled={connectionStatus === "scanning"}
                variant="outline"
              >
                <Scan className="h-4 w-4 mr-2" />
                {connectionStatus === "scanning" ? "Scanning..." : "Scan"}
              </Button>
              <Link href="/devices">
                <Button>Manage Devices</Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon
            const content = (
              <Button
                key={index}
                className={`h-24 flex-col space-y-2 ${action.color}`}
                onClick={action.action}
              >
                <Icon className="h-8 w-8" />
                <span className="text-sm">{action.label}</span>
              </Button>
            )

            return action.href ? (
              <Link key={index} href={action.href}>
                {content}
              </Link>
            ) : (
              content
            )
          })}
        </div>
      </div>

      {/* Recent Devices */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Your Devices</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {devices.slice(0, 6).map((device) => (
            <Card key={device.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Tv className="h-5 w-5" />
                  <span>{device.name}</span>
                </CardTitle>
                <CardDescription>
                  {device.brand} {device.model}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2 text-sm">
                      <div 
                        className={`w-2 h-2 rounded-full ${
                          device.isConnected ? 'bg-green-500' : 'bg-gray-400'
                        }`}
                      />
                      <span>{device.isConnected ? 'Connected' : 'Disconnected'}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Last used: {formatLastConnected(device.lastConnected)}
                    </p>
                  </div>
                  <Link href={`/remote/${device.id}`}>
                    <Button size="sm">
                      <Power className="h-4 w-4 mr-1" />
                      Control
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {devices.length > 6 && (
          <div className="mt-4 text-center">
            <Link href="/devices">
              <Button variant="outline">View All Devices</Button>
            </Link>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Devices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devices.length}</div>
            <p className="text-xs text-muted-foreground">
              Paired and available
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Connected Now</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{connectedDevices.length}</div>
            <p className="text-xs text-muted-foreground">
              Active connections
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Connection</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Wifi className="h-5 w-5 text-green-500" />
              <span className="font-medium">Bluetooth Ready</span>
            </div>
            <p className="text-xs text-muted-foreground">
              All systems operational
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}