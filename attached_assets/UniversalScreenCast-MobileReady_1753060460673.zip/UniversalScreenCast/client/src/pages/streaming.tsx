import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { apiRequest, queryClient } from "@/lib/queryClient"
import { useBluetooth } from "@/components/bluetooth-provider"
import { Play, Tv, ExternalLink } from "lucide-react"
import { SiNetflix, SiYoutube, SiSpotify, SiDisneyplus, SiAmazonprime } from "react-icons/si"
import type { StreamingContent, Device } from "../../shared/schema"

export function StreamingPage() {
  const { toast } = useToast()
  const { connectedDevice } = useBluetooth()

  const { data: content = [], isLoading } = useQuery<StreamingContent[]>({
    queryKey: ['/api/streaming/content'],
  })

  const { data: devices = [] } = useQuery<Device[]>({
    queryKey: ['/api/devices'],
  })

  const launchContentMutation = useMutation({
    mutationFn: async ({ deviceId, contentId }: { deviceId: string; contentId: string }) => {
      return apiRequest(`/api/streaming/launch/${deviceId}/${contentId}`, {
        method: 'POST',
      })
    },
    onSuccess: (data) => {
      toast({
        title: "Content Launched",
        description: `${data.content} is now playing on ${data.device}`,
      })
    },
    onError: (error) => {
      toast({
        title: "Launch Failed",
        description: error instanceof Error ? error.message : "Failed to launch content",
        variant: "destructive",
      })
    },
  })

  const handleLaunchContent = (contentId: string) => {
    if (!connectedDevice) {
      toast({
        title: "No Device Connected",
        description: "Please connect to a device first",
        variant: "destructive",
      })
      return
    }
    
    launchContentMutation.mutate({ deviceId: connectedDevice.id, contentId })
  }

  const getServiceIcon = (service: string) => {
    switch (service) {
      case 'netflix': return SiNetflix
      case 'youtube': return SiYoutube
      case 'spotify': return SiSpotify
      case 'disney_plus': return SiDisneyplus
      case 'prime_video': return SiAmazonprime
      default: return Play
    }
  }

  const getServiceColor = (service: string) => {
    switch (service) {
      case 'netflix': return 'bg-red-600 hover:bg-red-700'
      case 'youtube': return 'bg-red-500 hover:bg-red-600'
      case 'spotify': return 'bg-green-500 hover:bg-green-600'
      case 'disney_plus': return 'bg-blue-600 hover:bg-blue-700'
      case 'prime_video': return 'bg-blue-800 hover:bg-blue-900'
      default: return 'bg-gray-600 hover:bg-gray-700'
    }
  }

  const groupedContent = content.reduce((acc, item) => {
    const category = item.category || 'other'
    if (!acc[category]) {
      acc[category] = []
    }
    acc[category].push(item)
    return acc
  }, {} as Record<string, StreamingContent[]>)

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 w-48 bg-muted rounded mb-6"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-40 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Streaming</h1>
          <p className="text-muted-foreground">
            Launch your favorite streaming apps and content
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">
            {connectedDevice ? (
              <>Connected to <span className="font-medium">{connectedDevice.name}</span></>
            ) : (
              'No device connected'
            )}
          </p>
        </div>
      </div>

      {/* Quick Launch Apps */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Launch</CardTitle>
          <CardDescription>
            Launch popular streaming apps instantly
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {content.filter(item => item.type === 'app').map((app) => {
              const Icon = getServiceIcon(app.streamingService || '')
              const colorClass = getServiceColor(app.streamingService || '')
              
              return (
                <Button
                  key={app.id}
                  onClick={() => handleLaunchContent(app.id)}
                  disabled={!connectedDevice || launchContentMutation.isPending}
                  className={`h-24 flex-col space-y-2 ${colorClass} text-white`}
                >
                  <Icon className="h-8 w-8" />
                  <span className="text-sm font-medium">{app.title}</span>
                </Button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Content by Category */}
      {Object.entries(groupedContent).map(([category, items]) => (
        <div key={category}>
          <h2 className="text-xl font-semibold mb-4 capitalize">
            {category.replace('_', ' ')}
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {items.map((item) => {
              const Icon = getServiceIcon(item.streamingService || '')
              
              return (
                <Card key={item.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${getServiceColor(item.streamingService || '')} text-white`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                        <CardDescription className="capitalize">
                          {item.type.replace('_', ' ')} • {item.streamingService}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">
                        {item.thumbnail && (
                          <span className="text-2xl mr-2">{item.thumbnail}</span>
                        )}
                        {item.isAvailable ? 'Available' : 'Unavailable'}
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          onClick={() => handleLaunchContent(item.id)}
                          disabled={!connectedDevice || launchContentMutation.isPending || !item.isAvailable}
                          size="sm"
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Launch
                        </Button>
                        <Button variant="outline" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      ))}

      {/* Connected Devices */}
      <Card>
        <CardHeader>
          <CardTitle>Available Devices</CardTitle>
          <CardDescription>
            Select a device to stream content
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {devices.map((device) => (
              <div 
                key={device.id} 
                className={`flex items-center justify-between p-3 border rounded-lg ${
                  connectedDevice?.id === device.id ? 'border-primary bg-primary/5' : ''
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Tv className="h-5 w-5" />
                  <div>
                    <p className="font-medium">{device.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {device.brand} {device.model}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${device.isConnected ? 'bg-green-500' : 'bg-gray-400'}`} />
                  <span className="text-sm">
                    {device.isConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          {devices.length === 0 && (
            <div className="text-center py-8">
              <Tv className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                No devices found. Please add and connect a device first.
              </p>
              <Button className="mt-4" onClick={() => window.location.href = '/devices'}>
                Go to Devices
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {content.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Play className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Content Available</h3>
            <p className="text-muted-foreground">
              Content will be loaded automatically when you connect to a compatible device.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}