import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useTheme } from "@/components/theme-provider"
import { useBluetooth } from "@/components/bluetooth-provider"
import { apiRequest, queryClient } from "@/lib/queryClient"
import { 
  Moon, 
  Sun, 
  Monitor, 
  Bluetooth, 
  Tv, 
  Smartphone, 
  Tablet,
  Volume2,
  Settings as SettingsIcon,
  Info,
  Trash2
} from "lucide-react"
import type { UserPreferences } from "../../shared/schema"

export function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const { connectionStatus, isSupported } = useBluetooth()
  const { toast } = useToast()
  const [selectedLayout, setSelectedLayout] = useState<string>("standard")

  const { data: preferences } = useQuery<UserPreferences>({
    queryKey: ['/api/preferences/user-1'],
  })

  const updatePreferencesMutation = useMutation({
    mutationFn: async (updates: Partial<UserPreferences>) => {
      return apiRequest('/api/preferences/user-1', {
        method: 'PATCH',
        body: JSON.stringify(updates),
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/preferences/user-1'] })
      toast({
        title: "Settings Updated",
        description: "Your preferences have been saved",
      })
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update settings",
        variant: "destructive",
      })
    },
  })

  const handleThemeChange = (newTheme: "light" | "dark" | "system") => {
    setTheme(newTheme)
    updatePreferencesMutation.mutate({ theme: newTheme })
  }

  const handleLayoutChange = (layout: string) => {
    setSelectedLayout(layout)
    updatePreferencesMutation.mutate({ remoteLayout: layout })
  }

  const clearAllData = () => {
    if (confirm("Are you sure you want to clear all data? This will remove all devices and preferences.")) {
      // This would clear local storage and reset to defaults
      localStorage.clear()
      toast({
        title: "Data Cleared",
        description: "All local data has been cleared",
      })
      window.location.reload()
    }
  }

  const themeOptions = [
    { value: "light", label: "Light", icon: Sun, description: "Light theme for daytime use" },
    { value: "dark", label: "Dark", icon: Moon, description: "Dark theme for comfortable viewing" },
    { value: "system", label: "System", icon: Monitor, description: "Follow system preference" },
  ]

  const layoutOptions = [
    { value: "standard", label: "Standard", icon: Tv, description: "Classic TV remote layout" },
    { value: "minimal", label: "Minimal", icon: Smartphone, description: "Simplified mobile-friendly layout" },
    { value: "advanced", label: "Advanced", icon: Tablet, description: "Full-featured layout with all controls" },
  ]

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground">
          Customize your universal TV remote experience
        </p>
      </div>

      {/* Theme Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
          <CardDescription>
            Choose your preferred theme and display options
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">Theme</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {themeOptions.map((option) => {
                const Icon = option.icon
                return (
                  <Button
                    key={option.value}
                    variant={theme === option.value ? "default" : "outline"}
                    className="h-auto p-4 flex-col space-y-2"
                    onClick={() => handleThemeChange(option.value as any)}
                  >
                    <Icon className="h-6 w-6" />
                    <div className="text-center">
                      <div className="font-medium">{option.label}</div>
                      <div className="text-xs text-muted-foreground">
                        {option.description}
                      </div>
                    </div>
                  </Button>
                )
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Remote Layout */}
      <Card>
        <CardHeader>
          <CardTitle>Remote Control Layout</CardTitle>
          <CardDescription>
            Choose the remote control interface that works best for you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {layoutOptions.map((option) => {
              const Icon = option.icon
              const isSelected = (preferences?.remoteLayout || selectedLayout) === option.value
              
              return (
                <Button
                  key={option.value}
                  variant={isSelected ? "default" : "outline"}
                  className="h-auto p-4 flex-col space-y-2"
                  onClick={() => handleLayoutChange(option.value)}
                >
                  <Icon className="h-6 w-6" />
                  <div className="text-center">
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-muted-foreground">
                      {option.description}
                    </div>
                  </div>
                </Button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Bluetooth Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Bluetooth & Connectivity</CardTitle>
          <CardDescription>
            Manage device connections and Bluetooth settings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center space-x-3">
              <Bluetooth className="h-5 w-5 text-blue-500" />
              <div>
                <p className="font-medium">Bluetooth Status</p>
                <p className="text-sm text-muted-foreground">
                  {isSupported ? `Status: ${connectionStatus}` : "Not supported on this device"}
                </p>
              </div>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-medium ${
              connectionStatus === "connected" ? "bg-green-100 text-green-800" :
              connectionStatus === "connecting" ? "bg-yellow-100 text-yellow-800" :
              connectionStatus === "error" ? "bg-red-100 text-red-800" :
              "bg-gray-100 text-gray-800"
            }`}>
              {connectionStatus}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" onClick={() => window.location.href = '/devices'}>
              <Tv className="h-4 w-4 mr-2" />
              Manage Devices
            </Button>
            <Button variant="outline">
              <SettingsIcon className="h-4 w-4 mr-2" />
              Connection Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Customize your quick action buttons
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Current Quick Actions</h4>
              <div className="flex flex-wrap gap-2">
                {(preferences?.quickActions || []).map((action, index) => (
                  <div 
                    key={index}
                    className="px-3 py-1 bg-secondary text-secondary-foreground rounded-md text-sm flex items-center space-x-2"
                  >
                    <Volume2 className="h-3 w-3" />
                    <span>{action.replace('_', ' ')}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <Button variant="outline" size="sm">
              <SettingsIcon className="h-4 w-4 mr-2" />
              Customize Quick Actions
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle>System Information</CardTitle>
          <CardDescription>
            App version and device compatibility information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">App Version:</span>
                <span>1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Platform:</span>
                <span>Web</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Browser:</span>
                <span>{navigator.userAgent.split(' ')[0]}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Bluetooth Support:</span>
                <span>{isSupported ? 'Yes' : 'No'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Touch Support:</span>
                <span>{'ontouchstart' in window ? 'Yes' : 'No'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Screen Size:</span>
                <span>{window.screen.width}x{window.screen.height}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
          <CardDescription>
            Manage your stored data and preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg border-destructive/20">
            <div className="flex items-center space-x-3">
              <Trash2 className="h-5 w-5 text-destructive" />
              <div>
                <p className="font-medium">Clear All Data</p>
                <p className="text-sm text-muted-foreground">
                  Remove all stored devices, preferences, and settings
                </p>
              </div>
            </div>
            <Button variant="destructive" onClick={clearAllData}>
              Clear Data
            </Button>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-muted/50 rounded-lg">
            <Info className="h-5 w-5 text-blue-500 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium mb-1">Privacy Notice</p>
              <p className="text-muted-foreground">
                All your data is stored locally on your device. No personal information is sent to external servers.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}