import { useState } from "react"
import { useRoute } from "wouter"
import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { apiRequest, queryClient } from "@/lib/queryClient"
import { 
  Power,
  VolumeX,
  Volume1,
  Volume2,
  SkipBack,
  SkipForward,
  Play,
  Pause,
  Square,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Home,
  Menu,
  Settings
} from "lucide-react"
import { SiNetflix, SiYoutube, SiSpotify, SiDisneyplus, SiAmazonprime } from "react-icons/si"
import type { Device, RemoteCommand } from "../../shared/schema"

export function RemotePage() {
  const [, params] = useRoute("/remote/:deviceId?")
  const deviceId = params?.deviceId
  const { toast } = useToast()

  const { data: device, isLoading } = useQuery<Device>({
    queryKey: ['/api/devices', deviceId],
    queryFn: () => fetch(`/api/devices/${deviceId}`).then(res => res.json()),
    enabled: !!deviceId,
  })

  const { data: devices = [] } = useQuery<Device[]>({
    queryKey: ['/api/devices'],
  })

  const sendCommandMutation = useMutation({
    mutationFn: async ({ deviceId, command, value }: { deviceId: string; command: RemoteCommand; value?: string | number }) => {
      return apiRequest(`/api/remote/${deviceId}/command`, {
        method: 'POST',
        body: JSON.stringify({ command, value }),
      })
    },
    onSuccess: (data) => {
      toast({
        title: "Command Sent",
        description: `${data.command} executed on ${data.device}`,
      })
    },
    onError: (error) => {
      toast({
        title: "Command Failed",
        description: error instanceof Error ? error.message : "Failed to send command",
        variant: "destructive",
      })
    },
  })

  const sendCommand = (command: RemoteCommand, value?: string | number) => {
    if (!deviceId) {
      toast({
        title: "No Device Selected",
        description: "Please select a device first",
        variant: "destructive",
      })
      return
    }
    
    sendCommandMutation.mutate({ deviceId, command, value })
  }

  if (!deviceId && devices.length > 0) {
    const firstDevice = devices[0]
    window.location.href = `/remote/${firstDevice.id}`
    return null
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!device) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">No Device Found</h1>
          <p className="text-muted-foreground mb-4">
            The device you're looking for doesn't exist or isn't connected.
          </p>
          <Button onClick={() => window.location.href = '/devices'}>
            View All Devices
          </Button>
        </div>
      </div>
    )
  }

  const streamingApps = [
    { command: 'netflix' as RemoteCommand, icon: SiNetflix, label: 'Netflix', color: 'bg-red-600' },
    { command: 'youtube' as RemoteCommand, icon: SiYoutube, label: 'YouTube', color: 'bg-red-500' },
    { command: 'spotify' as RemoteCommand, icon: SiSpotify, label: 'Spotify', color: 'bg-green-500' },
    { command: 'disney_plus' as RemoteCommand, icon: SiDisneyplus, label: 'Disney+', color: 'bg-blue-600' },
    { command: 'prime_video' as RemoteCommand, icon: SiAmazonprime, label: 'Prime', color: 'bg-blue-800' },
  ]

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Device Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${device.isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
            <span>{device.name}</span>
          </CardTitle>
          <p className="text-muted-foreground">
            {device.brand} {device.model} • {device.isConnected ? 'Connected' : 'Disconnected'}
          </p>
        </CardHeader>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Power & Volume Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Power & Volume</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => sendCommand('power')}
              variant="remote"
              size="remote-lg"
              className="w-full bg-red-600 hover:bg-red-700"
            >
              <Power className="h-6 w-6" />
            </Button>
            
            <div className="grid grid-cols-3 gap-2">
              <Button
                onClick={() => sendCommand('volume_down')}
                variant="remote"
                size="remote"
              >
                <Volume1 className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('mute')}
                variant="remote"
                size="remote"
              >
                <VolumeX className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('volume_up')}
                variant="remote"
                size="remote"
              >
                <Volume2 className="h-5 w-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Navigation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div></div>
              <Button
                onClick={() => sendCommand('up')}
                variant="remote"
                size="remote"
              >
                <ArrowUp className="h-5 w-5" />
              </Button>
              <div></div>
              
              <Button
                onClick={() => sendCommand('left')}
                variant="remote"
                size="remote"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('ok')}
                variant="remote"
                size="remote"
                className="bg-blue-600 hover:bg-blue-700"
              >
                OK
              </Button>
              <Button
                onClick={() => sendCommand('right')}
                variant="remote"
                size="remote"
              >
                <ArrowRight className="h-5 w-5" />
              </Button>
              
              <div></div>
              <Button
                onClick={() => sendCommand('down')}
                variant="remote"
                size="remote"
              >
                <ArrowDown className="h-5 w-5" />
              </Button>
              <div></div>
            </div>
            
            <div className="grid grid-cols-3 gap-2">
              <Button
                onClick={() => sendCommand('back')}
                variant="remote"
                size="sm"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => sendCommand('home')}
                variant="remote"
                size="sm"
              >
                <Home className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => sendCommand('menu')}
                variant="remote"
                size="sm"
              >
                <Menu className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Media Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Media Controls</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-2 mb-4">
              <Button
                onClick={() => sendCommand('rewind')}
                variant="remote"
                size="remote"
              >
                <SkipBack className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('play_pause')}
                variant="remote"
                size="remote"
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('stop')}
                variant="remote"
                size="remote"
              >
                <Square className="h-5 w-5" />
              </Button>
              <Button
                onClick={() => sendCommand('fast_forward')}
                variant="remote"
                size="remote"
              >
                <SkipForward className="h-5 w-5" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => sendCommand('channel_down')}
                variant="outline"
                size="sm"
              >
                CH -
              </Button>
              <Button
                onClick={() => sendCommand('channel_up')}
                variant="outline"
                size="sm"
              >
                CH +
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Streaming Apps */}
        <Card>
          <CardHeader>
            <CardTitle>Streaming Apps</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              {streamingApps.map((app) => {
                const Icon = app.icon
                return (
                  <Button
                    key={app.command}
                    onClick={() => sendCommand(app.command)}
                    variant="remote"
                    size="remote"
                    className={`${app.color} hover:opacity-90 flex-col space-y-1`}
                  >
                    <Icon className="h-6 w-6" />
                    <span className="text-xs">{app.label}</span>
                  </Button>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Number Pad */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Number Pad</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3 max-w-xs mx-auto">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <Button
                key={num}
                onClick={() => sendCommand('ok', num)} // Simulate channel change
                variant="remote"
                size="remote"
                className="text-lg font-bold"
              >
                {num}
              </Button>
            ))}
            <Button
              onClick={() => sendCommand('ok', 0)}
              variant="remote"
              size="remote"
              className="text-lg font-bold col-start-2"
            >
              0
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Device Selector (if multiple devices) */}
      {devices.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Switch Device</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {devices.map((d) => (
                <Button
                  key={d.id}
                  variant={d.id === deviceId ? "default" : "outline"}
                  className="justify-start"
                  onClick={() => window.location.href = `/remote/${d.id}`}
                >
                  <div className={`w-2 h-2 rounded-full mr-2 ${d.isConnected ? 'bg-green-500' : 'bg-gray-400'}`} />
                  {d.name} ({d.brand})
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}