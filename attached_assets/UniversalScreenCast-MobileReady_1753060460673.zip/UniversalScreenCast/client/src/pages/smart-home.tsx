import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { apiRequest, queryClient } from "@/lib/queryClient"
import { 
  Lightbulb, 
  Thermometer, 
  Shield, 
  Speaker, 
  Power,
  Plus,
  Settings,
  Home as HomeIcon
} from "lucide-react"
import type { SmartHomeDevice } from "../../shared/schema"

export function SmartHomePage() {
  const [selectedRoom, setSelectedRoom] = useState<string>("all")
  const { toast } = useToast()

  const { data: devices = [], isLoading } = useQuery<SmartHomeDevice[]>({
    queryKey: ['/api/smarthome/devices'],
  })

  const executeCommandMutation = useMutation({
    mutationFn: async ({ deviceId, command, parameters }: { deviceId: string; command: string; parameters?: any }) => {
      return apiRequest(`/api/smarthome/devices/${deviceId}/command`, {
        method: 'POST',
        body: JSON.stringify({ command, parameters }),
      })
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/smarthome/devices'] })
      toast({
        title: "Command Executed",
        description: `${data.command} executed on ${data.device}`,
      })
    },
    onError: (error) => {
      toast({
        title: "Command Failed",
        description: error instanceof Error ? error.message : "Failed to execute command",
        variant: "destructive",
      })
    },
  })

  const executeCommand = (deviceId: string, command: string, parameters?: any) => {
    executeCommandMutation.mutate({ deviceId, command, parameters })
  }

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'lights': return Lightbulb
      case 'thermostat': return Thermometer
      case 'security': return Shield
      case 'speaker': return Speaker
      default: return Settings
    }
  }

  const getDeviceColor = (type: string) => {
    switch (type) {
      case 'lights': return 'text-yellow-500'
      case 'thermostat': return 'text-blue-500'
      case 'security': return 'text-red-500'
      case 'speaker': return 'text-green-500'
      default: return 'text-gray-500'
    }
  }

  const getRoomDevices = () => {
    if (selectedRoom === "all") return devices
    return devices.filter(device => device.room === selectedRoom)
  }

  const rooms = Array.from(new Set(devices.map(device => device.room).filter(Boolean)))

  const renderDeviceControls = (device: SmartHomeDevice) => {
    const currentState = device.currentState ? JSON.parse(device.currentState) : {}
    
    switch (device.type) {
      case 'lights':
        return (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">Power</span>
              <Button
                size="sm"
                variant={currentState.isOn ? "default" : "outline"}
                onClick={() => executeCommand(device.id, currentState.isOn ? 'turn_off' : 'turn_on')}
              >
                {currentState.isOn ? 'On' : 'Off'}
              </Button>
            </div>
            {currentState.isOn && (
              <div className="flex justify-between items-center">
                <span className="text-sm">Brightness: {currentState.brightness}%</span>
                <div className="flex space-x-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => executeCommand(device.id, 'dim')}
                  >
                    -
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => executeCommand(device.id, 'brighten')}
                  >
                    +
                  </Button>
                </div>
              </div>
            )}
          </div>
        )
        
      case 'thermostat':
        return (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">Current: {currentState.temperature}°F</span>
              <span className="text-sm">Target: {currentState.targetTemp}°F</span>
            </div>
            <div className="flex justify-center space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => executeCommand(device.id, 'set_temperature', { temp: currentState.targetTemp - 1 })}
              >
                -
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => executeCommand(device.id, 'set_temperature', { temp: currentState.targetTemp + 1 })}
              >
                +
              </Button>
            </div>
            <div className="text-center text-sm text-muted-foreground">
              Mode: {currentState.mode}
            </div>
          </div>
        )
        
      case 'security':
        return (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">Recording</span>
              <Button
                size="sm"
                variant={currentState.recording ? "destructive" : "default"}
                onClick={() => executeCommand(device.id, 'toggle_recording')}
              >
                {currentState.recording ? 'Stop' : 'Start'}
              </Button>
            </div>
            <div className="text-center">
              <Button
                size="sm"
                variant="outline"
                onClick={() => executeCommand(device.id, 'view_feed')}
              >
                View Feed
              </Button>
            </div>
            {currentState.motionDetected && (
              <div className="text-center text-sm text-red-500">
                Motion Detected!
              </div>
            )}
          </div>
        )
        
      default:
        return (
          <div className="space-y-2">
            <div className="flex flex-wrap gap-1">
              {device.supportedCommands?.map((command) => (
                <Button
                  key={command}
                  size="sm"
                  variant="outline"
                  onClick={() => executeCommand(device.id, command)}
                >
                  {command.replace('_', ' ')}
                </Button>
              ))}
            </div>
          </div>
        )
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 w-48 bg-muted rounded mb-6"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Smart Home</h1>
          <p className="text-muted-foreground">
            Control your connected smart home devices
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Device
        </Button>
      </div>

      {/* Room Filter */}
      <Card>
        <CardHeader>
          <CardTitle>Rooms</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedRoom === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedRoom("all")}
            >
              <HomeIcon className="h-4 w-4 mr-2" />
              All Rooms
            </Button>
            {rooms.map((room) => (
              <Button
                key={room}
                variant={selectedRoom === room ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedRoom(room || "")}
              >
                {room?.replace('_', ' ')}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Devices Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {getRoomDevices().map((device) => {
          const Icon = getDeviceIcon(device.type)
          const iconColor = getDeviceColor(device.type)
          
          return (
            <Card key={device.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Icon className={`h-6 w-6 ${iconColor}`} />
                    <div>
                      <CardTitle className="text-lg">{device.name}</CardTitle>
                      <CardDescription className="capitalize">
                        {device.type} • {device.room?.replace('_', ' ')}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${device.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
                    <span className="text-xs font-medium">
                      {device.isOnline ? 'Online' : 'Offline'}
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {device.isOnline ? (
                  renderDeviceControls(device)
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    Device is offline
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Common smart home controls
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              className="h-20 flex-col space-y-2"
              onClick={() => {
                devices.filter(d => d.type === 'lights').forEach(device => {
                  executeCommand(device.id, 'turn_off')
                })
              }}
            >
              <Lightbulb className="h-6 w-6" />
              <span className="text-sm">All Lights Off</span>
            </Button>
            
            <Button
              className="h-20 flex-col space-y-2"
              onClick={() => {
                devices.filter(d => d.type === 'lights').forEach(device => {
                  executeCommand(device.id, 'turn_on')
                })
              }}
            >
              <Lightbulb className="h-6 w-6" />
              <span className="text-sm">All Lights On</span>
            </Button>
            
            <Button
              className="h-20 flex-col space-y-2"
              onClick={() => {
                const thermostat = devices.find(d => d.type === 'thermostat')
                if (thermostat) {
                  executeCommand(thermostat.id, 'set_temperature', { temp: 72 })
                }
              }}
            >
              <Thermometer className="h-6 w-6" />
              <span className="text-sm">Set 72°F</span>
            </Button>
            
            <Button
              className="h-20 flex-col space-y-2"
              onClick={() => {
                devices.filter(d => d.type === 'security').forEach(device => {
                  executeCommand(device.id, 'toggle_recording')
                })
              }}
            >
              <Shield className="h-6 w-6" />
              <span className="text-sm">Security Check</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {devices.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <HomeIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Smart Home Devices</h3>
            <p className="text-muted-foreground mb-4">
              Connect smart home devices to control them from your TV remote.
            </p>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Smart Device
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}