import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Router, Route, Switch } from 'wouter'
import { Toaster } from '@/components/ui/toaster'
import { ThemeProvider } from '@/components/theme-provider'
import { BluetoothProvider } from '@/components/bluetooth-provider'
import { Layout } from '@/components/layout'
import { HomePage } from '@/pages/home'
import { RemotePage } from '@/pages/remote'
import { DevicesPage } from '@/pages/devices'
import { StreamingPage } from '@/pages/streaming'
import { SmartHomePage } from '@/pages/smart-home'
import { SettingsPage } from '@/pages/settings'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 2,
    },
  },
})

// Add default fetcher for TanStack Query
const defaultFetcher = async (url: string) => {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }
  return response.json()
}

queryClient.setDefaultOptions({
  queries: {
    queryFn: ({ queryKey }) => defaultFetcher(queryKey[0] as string),
  },
})

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="tv-remote-theme">
        <BluetoothProvider>
          <Router>
            <Layout>
              <Switch>
                <Route path="/" component={HomePage} />
                <Route path="/remote/:deviceId?" component={RemotePage} />
                <Route path="/devices" component={DevicesPage} />
                <Route path="/streaming" component={StreamingPage} />
                <Route path="/smart-home" component={SmartHomePage} />
                <Route path="/settings" component={SettingsPage} />
                <Route>
                  <div className="flex items-center justify-center min-h-[50vh]">
                    <div className="text-center">
                      <h1 className="text-2xl font-bold mb-4">Page Not Found</h1>
                      <p className="text-muted-foreground">The page you're looking for doesn't exist.</p>
                    </div>
                  </div>
                </Route>
              </Switch>
            </Layout>
          </Router>
          <Toaster />
        </BluetoothProvider>
      </ThemeProvider>
    </QueryClientProvider>
  )
}

export default App