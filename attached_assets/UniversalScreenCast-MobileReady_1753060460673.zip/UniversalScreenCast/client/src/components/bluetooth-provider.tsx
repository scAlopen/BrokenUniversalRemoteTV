import { createContext, useContext, useState, useEffect, ReactNode } from "react"
import { useToast } from "@/hooks/use-toast"
import type { BluetoothConnectionStatus, Device } from "../../shared/schema"

interface BluetoothContextType {
  connectionStatus: BluetoothConnectionStatus
  connectedDevice: Device | null
  availableDevices: Device[]
  scanForDevices: () => Promise<void>
  connectToDevice: (deviceId: string, pairingCode?: string) => Promise<void>
  disconnectDevice: (deviceId: string) => Promise<void>
  isSupported: boolean
}

const BluetoothContext = createContext<BluetoothContextType | undefined>(undefined)

export function BluetoothProvider({ children }: { children: ReactNode }) {
  const [connectionStatus, setConnectionStatus] = useState<BluetoothConnectionStatus>("disconnected")
  const [connectedDevice, setConnectedDevice] = useState<Device | null>(null)
  const [availableDevices, setAvailableDevices] = useState<Device[]>([])
  const [isSupported, setIsSupported] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if Web Bluetooth API is supported
    setIsSupported('bluetooth' in navigator)
    
    if (!('bluetooth' in navigator)) {
      toast({
        title: "Bluetooth Not Supported",
        description: "Web Bluetooth API is not supported on this device. Using simulated connection.",
        variant: "default"
      })
    }
  }, [toast])

  const scanForDevices = async () => {
    setConnectionStatus("scanning")
    
    try {
      const response = await fetch('/api/bluetooth/scan', {
        method: 'POST',
      })
      
      if (!response.ok) {
        throw new Error('Failed to scan for devices')
      }
      
      const result = await response.json()
      setAvailableDevices(result.devices || [])
      setConnectionStatus("disconnected")
      
      toast({
        title: "Scan Complete",
        description: `Found ${result.devices?.length || 0} available devices`,
      })
    } catch (error) {
      setConnectionStatus("error")
      toast({
        title: "Scan Failed",
        description: "Failed to scan for Bluetooth devices",
        variant: "destructive"
      })
    }
  }

  const connectToDevice = async (deviceId: string, pairingCode?: string) => {
    setConnectionStatus("connecting")
    
    try {
      const response = await fetch(`/api/bluetooth/connect/${deviceId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ pairingCode }),
      })
      
      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Failed to connect')
      }
      
      const result = await response.json()
      setConnectedDevice(result.device)
      setConnectionStatus("connected")
      
      toast({
        title: "Connected",
        description: `Successfully connected to ${result.device.name}`,
      })
    } catch (error) {
      setConnectionStatus("error")
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect to device",
        variant: "destructive"
      })
    }
  }

  const disconnectDevice = async (deviceId: string) => {
    try {
      const response = await fetch(`/api/bluetooth/disconnect/${deviceId}`, {
        method: 'POST',
      })
      
      if (!response.ok) {
        throw new Error('Failed to disconnect')
      }
      
      setConnectedDevice(null)
      setConnectionStatus("disconnected")
      
      toast({
        title: "Disconnected",
        description: "Device disconnected successfully",
      })
    } catch (error) {
      toast({
        title: "Disconnect Failed",
        description: "Failed to disconnect device",
        variant: "destructive"
      })
    }
  }

  return (
    <BluetoothContext.Provider
      value={{
        connectionStatus,
        connectedDevice,
        availableDevices,
        scanForDevices,
        connectToDevice,
        disconnectDevice,
        isSupported,
      }}
    >
      {children}
    </BluetoothContext.Provider>
  )
}

export function useBluetooth() {
  const context = useContext(BluetoothContext)
  if (context === undefined) {
    throw new Error("useBluetooth must be used within a BluetoothProvider")
  }
  return context
}