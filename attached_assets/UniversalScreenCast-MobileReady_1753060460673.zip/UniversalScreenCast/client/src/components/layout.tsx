import { ReactNode } from "react"
import { Link, useLocation } from "wouter"
import { cn } from "@/lib/utils"
import { 
  Home, 
  Radio, 
  Devices, 
  Play, 
  Home as SmartHome, 
  Settings, 
  Bluetooth,
  Tv
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useBluetooth } from "@/components/bluetooth-provider"

interface LayoutProps {
  children: ReactNode
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation()
  const { connectionStatus, connectedDevice } = useBluetooth()

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/remote", icon: Radio, label: "Remote" },
    { path: "/devices", icon: Devices, label: "Devices" },
    { path: "/streaming", icon: Play, label: "Streaming" },
    { path: "/smart-home", icon: SmartHome, label: "Smart Home" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ]

  const getStatusColor = () => {
    switch (connectionStatus) {
      case "connected": return "text-green-500"
      case "connecting": return "text-yellow-500"
      case "scanning": return "text-blue-500"
      case "error": return "text-red-500"
      default: return "text-gray-500"
    }
  }

  return (
    <div className="flex flex-col min-h-screen p-2 sm:p-4 "min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex flex-col min-h-screen p-2 sm:p-4 "container mx-auto px-4 py-4">
          <div className="flex flex-col min-h-screen p-2 sm:p-4 "flex items-center justify-between">
            <div className="flex flex-col min-h-screen p-2 sm:p-4 "flex items-center space-x-4">
              <Tv className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">Universal TV Remote</h1>
            </div>
            
            <div className="flex flex-col min-h-screen p-2 sm:p-4 "flex items-center space-x-4">
              <div className="flex flex-col min-h-screen p-2 sm:p-4 "flex items-center space-x-2 text-sm">
                <Bluetooth className={cn("h-4 w-4", getStatusColor())} />
                <span className="hidden sm:inline">
                  {connectedDevice ? connectedDevice.name : connectionStatus}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-col min-h-screen p-2 sm:p-4 "flex">
        {/* Sidebar Navigation */}
        <nav className="w-64 border-r bg-card/30 min-h-[calc(100vh-80px)] p-4 hidden md:block">
          <div className="flex flex-col min-h-screen p-2 sm:p-4 "space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = location === item.path || 
                             (item.path === "/remote" && location.startsWith("/remote"))
              
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    className="w-full justify-start"
                  >
                    <Icon className="mr-2 h-4 w-4" />
                    {item.label}
                  </Button>
                </Link>
              )
            })}
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t">
        <div className="flex flex-col min-h-screen p-2 sm:p-4 "grid grid-cols-6 gap-1 p-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location === item.path || 
                           (item.path === "/remote" && location.startsWith("/remote"))
            
            return (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className="flex flex-col h-12 w-full text-xs"
                >
                  <Icon className="h-4 w-4 mb-1" />
                  <span className="truncate">{item.label}</span>
                </Button>
              </Link>
            )
          })}
        </div>
      </nav>
      
      {/* Add bottom padding for mobile navigation */}
      <div className="flex flex-col min-h-screen p-2 sm:p-4 "h-16 md:hidden" />
    </div>
  )
}