import { 
  Device, InsertDevice,
  RemoteSession, InsertRemoteSession,
  StreamingContent, InsertStreamingContent,
  SmartHomeDevice, InsertSmartHomeDevice,
  UserPreferences, InsertUserPreferences,
  RemoteCommand,
  BluetoothConnectionStatus
} from "../shared/schema";

export interface IStorage {
  // Device management
  getDevices(): Promise<Device[]>;
  getDevice(id: string): Promise<Device | null>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: string, updates: Partial<Device>): Promise<Device | null>;
  deleteDevice(id: string): Promise<boolean>;
  getConnectedDevices(): Promise<Device[]>;
  
  // Remote sessions
  createRemoteSession(session: InsertRemoteSession): Promise<RemoteSession>;
  getActiveSession(deviceId: string): Promise<RemoteSession | null>;
  endRemoteSession(sessionId: string): Promise<boolean>;
  updateSessionActivity(sessionId: string): Promise<void>;
  
  // Streaming content
  getStreamingContent(): Promise<StreamingContent[]>;
  getContentByService(service: string): Promise<StreamingContent[]>;
  createStreamingContent(content: InsertStreamingContent): Promise<StreamingContent>;
  
  // Smart home devices
  getSmartHomeDevices(): Promise<SmartHomeDevice[]>;
  getSmartHomeDevicesByRoom(room: string): Promise<SmartHomeDevice[]>;
  createSmartHomeDevice(device: InsertSmartHomeDevice): Promise<SmartHomeDevice>;
  updateSmartHomeDevice(id: string, updates: Partial<SmartHomeDevice>): Promise<SmartHomeDevice | null>;
  
  // User preferences
  getUserPreferences(userId: string): Promise<UserPreferences | null>;
  createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: string, updates: Partial<UserPreferences>): Promise<UserPreferences | null>;
}

export class MemStorage implements IStorage {
  private devices: Map<string, Device> = new Map();
  private remoteSessions: Map<string, RemoteSession> = new Map();
  private streamingContent: Map<string, StreamingContent> = new Map();
  private smartHomeDevices: Map<string, SmartHomeDevice> = new Map();
  private userPreferences: Map<string, UserPreferences> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Sample TVs and devices
    const sampleDevices: Device[] = [
      {
        id: "tv-1",
        name: "Living Room TV",
        type: "tv",
        brand: "Samsung",
        model: "QN85A",
        bluetoothId: "bt-samsung-001",
        ipAddress: "192.168.1.100",
        isConnected: false,
        lastConnected: new Date("2025-07-20T20:30:00Z"),
        supportedFeatures: ["volume", "power", "channels", "streaming", "smart_hub"],
        pairingCode: "1234",
        isPaired: true,
      },
      {
        id: "tv-2",
        name: "Bedroom TV",
        type: "tv",
        brand: "LG",
        model: "C1 OLED",
        bluetoothId: "bt-lg-002",
        ipAddress: "192.168.1.101",
        isConnected: false,
        lastConnected: new Date("2025-07-19T22:15:00Z"),
        supportedFeatures: ["volume", "power", "channels", "streaming", "webos"],
        pairingCode: "5678",
        isPaired: true,
      },
      {
        id: "device-1",
        name: "Apple TV 4K",
        type: "streaming_device",
        brand: "Apple",
        model: "A2843",
        bluetoothId: "bt-apple-003",
        ipAddress: "192.168.1.102",
        isConnected: false,
        lastConnected: new Date("2025-07-21T10:00:00Z"),
        supportedFeatures: ["streaming", "siri", "airplay"],
        pairingCode: "9876",
        isPaired: false,
      },
      {
        id: "device-2",
        name: "Soundbar",
        type: "audio",
        brand: "Sonos",
        model: "Arc",
        bluetoothId: "bt-sonos-004",
        ipAddress: "192.168.1.103",
        isConnected: false,
        lastConnected: new Date("2025-07-21T09:30:00Z"),
        supportedFeatures: ["volume", "audio_modes", "voice_control"],
        pairingCode: "4321",
        isPaired: true,
      }
    ];

    // Sample streaming content
    const sampleContent: StreamingContent[] = [
      {
        id: "content-1",
        title: "Netflix",
        type: "app",
        thumbnail: "🎬",
        streamingService: "netflix",
        category: "entertainment",
        isAvailable: true,
      },
      {
        id: "content-2",
        title: "YouTube",
        type: "app",
        thumbnail: "📺",
        streamingService: "youtube",
        category: "entertainment",
        isAvailable: true,
      },
      {
        id: "content-3",
        title: "Spotify",
        type: "app",
        thumbnail: "🎵",
        streamingService: "spotify",
        category: "music",
        isAvailable: true,
      },
      {
        id: "content-4",
        title: "Disney+",
        type: "app",
        thumbnail: "🏰",
        streamingService: "disney_plus",
        category: "entertainment",
        isAvailable: true,
      },
      {
        id: "content-5",
        title: "Prime Video",
        type: "app",
        thumbnail: "📽️",
        streamingService: "prime_video",
        category: "entertainment",
        isAvailable: true,
      }
    ];

    // Sample smart home devices
    const sampleSmartDevices: SmartHomeDevice[] = [
      {
        id: "smart-1",
        name: "Living Room Lights",
        type: "lights",
        room: "living_room",
        isOnline: true,
        currentState: JSON.stringify({ brightness: 80, color: "warm_white", isOn: true }),
        supportedCommands: ["turn_on", "turn_off", "dim", "brighten", "change_color"],
      },
      {
        id: "smart-2",
        name: "Thermostat",
        type: "thermostat",
        room: "living_room",
        isOnline: true,
        currentState: JSON.stringify({ temperature: 72, mode: "auto", targetTemp: 75 }),
        supportedCommands: ["set_temperature", "change_mode", "schedule"],
      },
      {
        id: "smart-3",
        name: "Security Camera",
        type: "security",
        room: "front_door",
        isOnline: true,
        currentState: JSON.stringify({ recording: true, motionDetected: false }),
        supportedCommands: ["view_feed", "toggle_recording", "motion_alerts"],
      }
    ];

    // Store sample data
    sampleDevices.forEach(device => this.devices.set(device.id, device));
    sampleContent.forEach(content => this.streamingContent.set(content.id, content));
    sampleSmartDevices.forEach(device => this.smartHomeDevices.set(device.id, device));

    // Default user preferences
    const defaultPrefs: UserPreferences = {
      id: "pref-1",
      userId: "user-1",
      favoriteDevices: ["tv-1", "device-1"],
      remoteLayout: "standard",
      theme: "dark",
      quickActions: ["netflix", "youtube", "volume_up", "volume_down"],
    };
    this.userPreferences.set("user-1", defaultPrefs);
  }

  // Device methods
  async getDevices(): Promise<Device[]> {
    return Array.from(this.devices.values());
  }

  async getDevice(id: string): Promise<Device | null> {
    return this.devices.get(id) || null;
  }

  async createDevice(device: InsertDevice): Promise<Device> {
    const newDevice: Device = {
      ...device,
      lastConnected: null,
    };
    this.devices.set(newDevice.id, newDevice);
    return newDevice;
  }

  async updateDevice(id: string, updates: Partial<Device>): Promise<Device | null> {
    const device = this.devices.get(id);
    if (!device) return null;
    
    const updated = { ...device, ...updates };
    this.devices.set(id, updated);
    return updated;
  }

  async deleteDevice(id: string): Promise<boolean> {
    return this.devices.delete(id);
  }

  async getConnectedDevices(): Promise<Device[]> {
    return Array.from(this.devices.values()).filter(device => device.isConnected);
  }

  // Remote session methods
  async createRemoteSession(session: InsertRemoteSession): Promise<RemoteSession> {
    const newSession: RemoteSession = {
      ...session,
      startedAt: new Date(),
      lastActivity: new Date(),
    };
    this.remoteSessions.set(newSession.id, newSession);
    return newSession;
  }

  async getActiveSession(deviceId: string): Promise<RemoteSession | null> {
    const sessions = Array.from(this.remoteSessions.values());
    return sessions.find(session => session.deviceId === deviceId && session.isActive) || null;
  }

  async endRemoteSession(sessionId: string): Promise<boolean> {
    const session = this.remoteSessions.get(sessionId);
    if (!session) return false;
    
    session.isActive = false;
    this.remoteSessions.set(sessionId, session);
    return true;
  }

  async updateSessionActivity(sessionId: string): Promise<void> {
    const session = this.remoteSessions.get(sessionId);
    if (session) {
      session.lastActivity = new Date();
      this.remoteSessions.set(sessionId, session);
    }
  }

  // Streaming content methods
  async getStreamingContent(): Promise<StreamingContent[]> {
    return Array.from(this.streamingContent.values());
  }

  async getContentByService(service: string): Promise<StreamingContent[]> {
    return Array.from(this.streamingContent.values()).filter(content => content.streamingService === service);
  }

  async createStreamingContent(content: InsertStreamingContent): Promise<StreamingContent> {
    this.streamingContent.set(content.id, content);
    return content;
  }

  // Smart home methods
  async getSmartHomeDevices(): Promise<SmartHomeDevice[]> {
    return Array.from(this.smartHomeDevices.values());
  }

  async getSmartHomeDevicesByRoom(room: string): Promise<SmartHomeDevice[]> {
    return Array.from(this.smartHomeDevices.values()).filter(device => device.room === room);
  }

  async createSmartHomeDevice(device: InsertSmartHomeDevice): Promise<SmartHomeDevice> {
    this.smartHomeDevices.set(device.id, device);
    return device;
  }

  async updateSmartHomeDevice(id: string, updates: Partial<SmartHomeDevice>): Promise<SmartHomeDevice | null> {
    const device = this.smartHomeDevices.get(id);
    if (!device) return null;
    
    const updated = { ...device, ...updates };
    this.smartHomeDevices.set(id, updated);
    return updated;
  }

  // User preferences methods
  async getUserPreferences(userId: string): Promise<UserPreferences | null> {
    return this.userPreferences.get(userId) || null;
  }

  async createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    this.userPreferences.set(preferences.userId, preferences);
    return preferences;
  }

  async updateUserPreferences(userId: string, updates: Partial<UserPreferences>): Promise<UserPreferences | null> {
    const prefs = this.userPreferences.get(userId);
    if (!prefs) return null;
    
    const updated = { ...prefs, ...updates };
    this.userPreferences.set(userId, updated);
    return updated;
  }
}

export const storage = new MemStorage();