import { Router } from "express";
import { z } from "zod";
import { storage } from "./storage";
import { 
  insertDeviceSchema, 
  insertRemoteSessionSchema,
  insertStreamingContentSchema,
  insertSmartHomeDeviceSchema,
  insertUserPreferencesSchema,
  type RemoteCommand,
  type BluetoothConnectionStatus
} from "../shared/schema";

const router = Router();

// Validation middleware
const validateBody = (schema: z.ZodSchema) => (req: any, res: any, next: any) => {
  try {
    req.body = schema.parse(req.body);
    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    return res.status(400).json({ error: "Invalid request body" });
  }
};

// Device management routes
router.get("/api/devices", async (req, res) => {
  try {
    const devices = await storage.getDevices();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch devices" });
  }
});

router.get("/api/devices/connected", async (req, res) => {
  try {
    const devices = await storage.getConnectedDevices();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch connected devices" });
  }
});

router.get("/api/devices/:id", async (req, res) => {
  try {
    const device = await storage.getDevice(req.params.id);
    if (!device) {
      return res.status(404).json({ error: "Device not found" });
    }
    res.json(device);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch device" });
  }
});

router.post("/api/devices", validateBody(insertDeviceSchema), async (req, res) => {
  try {
    const device = await storage.createDevice(req.body);
    res.status(201).json(device);
  } catch (error) {
    res.status(500).json({ error: "Failed to create device" });
  }
});

router.patch("/api/devices/:id", async (req, res) => {
  try {
    const device = await storage.updateDevice(req.params.id, req.body);
    if (!device) {
      return res.status(404).json({ error: "Device not found" });
    }
    res.json(device);
  } catch (error) {
    res.status(500).json({ error: "Failed to update device" });
  }
});

router.delete("/api/devices/:id", async (req, res) => {
  try {
    const success = await storage.deleteDevice(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Device not found" });
    }
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: "Failed to delete device" });
  }
});

// Bluetooth connection simulation
router.post("/api/bluetooth/scan", async (req, res) => {
  try {
    // Simulate Bluetooth scanning
    const devices = await storage.getDevices();
    const bluetoothDevices = devices.filter(device => device.bluetoothId && !device.isConnected);
    
    // Simulate scanning delay
    setTimeout(() => {
      res.json({
        status: "scanning_complete",
        devices: bluetoothDevices.map(device => ({
          id: device.id,
          name: device.name,
          bluetoothId: device.bluetoothId,
          type: device.type,
          brand: device.brand,
          isPaired: device.isPaired
        }))
      });
    }, 1000);
  } catch (error) {
    res.status(500).json({ error: "Failed to scan for devices" });
  }
});

router.post("/api/bluetooth/connect/:deviceId", async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { pairingCode } = req.body;
    
    const device = await storage.getDevice(deviceId);
    if (!device) {
      return res.status(404).json({ error: "Device not found" });
    }
    
    // Simulate pairing verification
    if (device.pairingCode && device.pairingCode !== pairingCode) {
      return res.status(400).json({ error: "Invalid pairing code" });
    }
    
    // Update device connection status
    const updatedDevice = await storage.updateDevice(deviceId, {
      isConnected: true,
      isPaired: true,
      lastConnected: new Date()
    });
    
    res.json({
      status: "connected",
      device: updatedDevice
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to connect to device" });
  }
});

router.post("/api/bluetooth/disconnect/:deviceId", async (req, res) => {
  try {
    const { deviceId } = req.params;
    
    const updatedDevice = await storage.updateDevice(deviceId, {
      isConnected: false
    });
    
    if (!updatedDevice) {
      return res.status(404).json({ error: "Device not found" });
    }
    
    res.json({
      status: "disconnected",
      device: updatedDevice
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to disconnect device" });
  }
});

// Remote control commands
router.post("/api/remote/:deviceId/command", async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { command, value } = req.body;
    
    const device = await storage.getDevice(deviceId);
    if (!device) {
      return res.status(404).json({ error: "Device not found" });
    }
    
    if (!device.isConnected) {
      return res.status(400).json({ error: "Device not connected" });
    }
    
    // Simulate command execution
    console.log(`Executing command ${command} on device ${device.name}${value ? ` with value ${value}` : ''}`);
    
    // Update session activity
    const activeSession = await storage.getActiveSession(deviceId);
    if (activeSession) {
      await storage.updateSessionActivity(activeSession.id);
    }
    
    res.json({
      status: "command_sent",
      command,
      device: device.name,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to send command" });
  }
});

// Remote sessions
router.post("/api/remote/sessions", validateBody(insertRemoteSessionSchema), async (req, res) => {
  try {
    const session = await storage.createRemoteSession(req.body);
    res.status(201).json(session);
  } catch (error) {
    res.status(500).json({ error: "Failed to create remote session" });
  }
});

router.get("/api/remote/sessions/:deviceId/active", async (req, res) => {
  try {
    const session = await storage.getActiveSession(req.params.deviceId);
    if (!session) {
      return res.status(404).json({ error: "No active session found" });
    }
    res.json(session);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch active session" });
  }
});

router.post("/api/remote/sessions/:sessionId/end", async (req, res) => {
  try {
    const success = await storage.endRemoteSession(req.params.sessionId);
    if (!success) {
      return res.status(404).json({ error: "Session not found" });
    }
    res.json({ status: "session_ended" });
  } catch (error) {
    res.status(500).json({ error: "Failed to end session" });
  }
});

// Streaming content
router.get("/api/streaming/content", async (req, res) => {
  try {
    const content = await storage.getStreamingContent();
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch streaming content" });
  }
});

router.get("/api/streaming/content/:service", async (req, res) => {
  try {
    const content = await storage.getContentByService(req.params.service);
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch content for service" });
  }
});

router.post("/api/streaming/launch/:deviceId/:contentId", async (req, res) => {
  try {
    const { deviceId, contentId } = req.params;
    
    const device = await storage.getDevice(deviceId);
    const content = await storage.getStreamingContent();
    const targetContent = content.find(c => c.id === contentId);
    
    if (!device || !targetContent) {
      return res.status(404).json({ error: "Device or content not found" });
    }
    
    if (!device.isConnected) {
      return res.status(400).json({ error: "Device not connected" });
    }
    
    console.log(`Launching ${targetContent.title} on ${device.name}`);
    
    res.json({
      status: "launched",
      content: targetContent.title,
      device: device.name
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to launch content" });
  }
});

// Smart home devices
router.get("/api/smarthome/devices", async (req, res) => {
  try {
    const devices = await storage.getSmartHomeDevices();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch smart home devices" });
  }
});

router.get("/api/smarthome/devices/room/:room", async (req, res) => {
  try {
    const devices = await storage.getSmartHomeDevicesByRoom(req.params.room);
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch devices for room" });
  }
});

router.post("/api/smarthome/devices/:deviceId/command", async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { command, parameters } = req.body;
    
    const device = await storage.getSmartHomeDevices();
    const targetDevice = device.find(d => d.id === deviceId);
    
    if (!targetDevice) {
      return res.status(404).json({ error: "Smart home device not found" });
    }
    
    if (!targetDevice.isOnline) {
      return res.status(400).json({ error: "Device is offline" });
    }
    
    console.log(`Executing smart home command ${command} on ${targetDevice.name}`, parameters);
    
    res.json({
      status: "command_executed",
      device: targetDevice.name,
      command,
      parameters
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to execute smart home command" });
  }
});

// User preferences
router.get("/api/preferences/:userId", async (req, res) => {
  try {
    const preferences = await storage.getUserPreferences(req.params.userId);
    if (!preferences) {
      return res.status(404).json({ error: "User preferences not found" });
    }
    res.json(preferences);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch user preferences" });
  }
});

router.post("/api/preferences", validateBody(insertUserPreferencesSchema), async (req, res) => {
  try {
    const preferences = await storage.createUserPreferences(req.body);
    res.status(201).json(preferences);
  } catch (error) {
    res.status(500).json({ error: "Failed to create user preferences" });
  }
});

router.patch("/api/preferences/:userId", async (req, res) => {
  try {
    const preferences = await storage.updateUserPreferences(req.params.userId, req.body);
    if (!preferences) {
      return res.status(404).json({ error: "User preferences not found" });
    }
    res.json(preferences);
  } catch (error) {
    res.status(500).json({ error: "Failed to update user preferences" });
  }
});

export default router;