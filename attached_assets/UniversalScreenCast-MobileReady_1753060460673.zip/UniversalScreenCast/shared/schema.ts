import { z } from "zod";

// Device schema for TVs, streaming devices, smart home devices
export const deviceSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.string(), // "tv", "streaming_device", "smart_speaker", etc.
  brand: z.string().optional(),
  model: z.string().optional(),
  bluetoothId: z.string().optional(),
  ipAddress: z.string().optional(),
  isConnected: z.boolean().default(false),
  lastConnected: z.date().nullable().optional(),
  supportedFeatures: z.array(z.string()).default([]), // ["volume", "power", "channels", "streaming"]
  pairingCode: z.string().optional(),
  isPaired: z.boolean().default(false),
});

// Remote Control Sessions schema
export const remoteSessionSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  userId: z.string().optional(),
  isActive: z.boolean().default(true),
  startedAt: z.date().optional(),
  lastActivity: z.date().optional(),
});

// Streaming Content schema
export const streamingContentSchema = z.object({
  id: z.string(),
  title: z.string(),
  type: z.string(), // "movie", "tv_show", "live_tv", "app"
  thumbnail: z.string().optional(),
  streamingService: z.string().optional(), // "netflix", "youtube", "spotify", etc.
  category: z.string().optional(),
  isAvailable: z.boolean().default(true),
});

// Smart Home Devices schema
export const smartHomeDeviceSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.string(), // "lights", "thermostat", "security", "speaker"
  room: z.string().optional(),
  isOnline: z.boolean().default(false),
  currentState: z.string().optional(), // JSON string for device-specific state
  supportedCommands: z.array(z.string()).default([]),
});

// User Preferences schema
export const userPreferencesSchema = z.object({
  id: z.string(),
  userId: z.string(),
  favoriteDevices: z.array(z.string()).default([]),
  remoteLayout: z.string().default("standard"), // "standard", "minimal", "advanced"
  theme: z.string().default("dark"), // "dark", "light", "auto"
  quickActions: z.array(z.string()).default([]), // Custom quick action buttons
});

// Insert schemas (for creating new entries)
export const insertDeviceSchema = deviceSchema.omit({
  lastConnected: true,
});

export const insertRemoteSessionSchema = remoteSessionSchema.omit({
  startedAt: true,
  lastActivity: true,
});

export const insertStreamingContentSchema = streamingContentSchema;

export const insertSmartHomeDeviceSchema = smartHomeDeviceSchema;

export const insertUserPreferencesSchema = userPreferencesSchema;

// Types
export type Device = z.infer<typeof deviceSchema>;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type RemoteSession = z.infer<typeof remoteSessionSchema>;
export type InsertRemoteSession = z.infer<typeof insertRemoteSessionSchema>;

export type StreamingContent = z.infer<typeof streamingContentSchema>;
export type InsertStreamingContent = z.infer<typeof insertStreamingContentSchema>;

export type SmartHomeDevice = z.infer<typeof smartHomeDeviceSchema>;
export type InsertSmartHomeDevice = z.infer<typeof insertSmartHomeDeviceSchema>;

export type UserPreferences = z.infer<typeof userPreferencesSchema>;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;

// Command types for remote control
export type RemoteCommand = 
  | "power"
  | "volume_up"
  | "volume_down"
  | "mute"
  | "channel_up"
  | "channel_down"
  | "menu"
  | "home"
  | "back"
  | "ok"
  | "up"
  | "down"
  | "left"
  | "right"
  | "netflix"
  | "youtube"
  | "spotify"
  | "disney_plus"
  | "prime_video"
  | "play_pause"
  | "stop"
  | "rewind"
  | "fast_forward";

export type BluetoothConnectionStatus = "disconnected" | "scanning" | "connecting" | "connected" | "error";